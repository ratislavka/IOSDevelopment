//
//  ViewController.swift
//  My Favorites
//
//  Created by Ratislav Ovchinnikov on 09.11.2025.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var tableView: UITableView!
    
    let items: [Item] = [
        Item(image: .lotr, title: "LOTR", subtitle: "LOTR", review: "great movie"),
        Item(image: .f1Themovie, title: "F1: The Movie", subtitle: "Apple TV", review: """
            "As an F1 fan in general, not a hardcore though, Im not sure what other fans are complaining about.
             
             I, for one, really liked it. It brought some really interesting and very much needed action and creative strategies that current formula one lacks.

             The film has some really entertaining moments that Brad Pitt's character creates. Yes, not all of them very realistic, but then again, it's a movie, and it does it to entertain us.

             It is an advertisement, but one hell of a good one, I must say. Even those not into the sport find it an interesting watch.

             So, if you're thinking about it, just go ahead already and watch it!

             It's a very well made movie that deserves your attention.

             Respect to Hans Zimmer, great as always.
        """)
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }


}



extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count // return 5
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return data.count //return 4
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell") as! FavoriteItemTableViewCell
        
        let currentItem = items[indexPath.row]
        cell.configure(item: currentItem)
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return data.section
    }
    

}



extension ViewController: UITableViewDelegate {
    
}
