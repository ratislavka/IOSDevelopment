//
//  Item.swift
//  My Favorites
//
//  Created by Ratislav Ovchinnikov on 14.11.2025.
//

import UIKit

struct Item {
    let image: UIImage
    let title: String
    let subtitle: String
    let review: String
    
}

struct FavoritesData {
    let section: String
    let items: [Item]
}


let data = [
    FavoritesData(section: "Movies", items: [
        Item(image: .lotr, title: "LOTR", subtitle: "Peter Jackson", review: "great movie"),
    ]),
    FavoritesData(section: "Books", items: [
        Item(image: <#T##UIImage#>, title: "Project Hail Mary", subtitle: "..", review: <#T##String#>)
    ]),
    FavoritesData(section: "Music", items: [
        Item(image: <#T##UIImage#>, title: "We are the Champions", subtitle: "Queen", review: <#T##String#>)
    ])
]
